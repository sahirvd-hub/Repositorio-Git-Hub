

ACTIVIDAD 2

PARTE 1: Personalización del MOTD 

Una vez cambiada la ip por una fija entramos por ssh e iremos al directorio Home para luego hacer un ls y veremos un archivo llamado 

MISION_STARFLEET_OPS_PROTOCOL_47-A

Ahí encontraremos información de las misiones que debemos realizar

Ahora haremos sudo nano /etc/motd para configurarlo a nuestro gusto y configuraciones respectivas


PARTE 2: Instalación de la Pila LAMP

**Primero:** Debemos realizar este comando: 

sudo apt update && sudo apt upgrade -S


**Segundo**: Instalamos Apache:

sudo apt install apache2

sudo systemctl enable apache2

sudo systemctl start apache2

sudo systemctl status apache2


**Tercero:** Instalamo MySQL/MariaDB:

sudo apt install mariadb-server

sudo systemctl enable mariadb

sudo systemctl start mariadb

sudo mysql_secure_installation

Cuarto: Instalamos PHP:

sudo apt install php libapache2-mod-php php-mysql 

sudo systemctl restart apache2

  

PARTE3: Verificar que todo funciona

Comprobación si los servicios funcionan correctamente

  

sudo systemctl status apache2

sudo systemctl status mariadb

  

Crearemos un archivo prueba de PHP:

  

Nos moveremos a esta carpeta 

sudo nano /var/www/html/info.php

  

Y realizaremos esto

<?php

phpinfo();

?>

  

Ahora probaremos si funciona correctamente abriremos un navegador

  

[http://192.168.1.52/info.php](http://192.168.1.52/info.php)

  
  
  
  

ACTIVIDAD 3

  

Habilitar UFW

sudo ufw enable

  

Resetear configuración previa (opcional pero recomendado)

sudo ufw reset

  

Permitir el canal de comunicación principal (SSH)

sudo ufw allow 22/tcp

  

Permitir tráfico web HTTP y HTTPS

sudo ufw allow 80/tcp

sudo ufw allow 443/tcp

  

Bloquear todo lo demás

sudo ufw default deny incoming

sudo ufw default allow outgoing

  

Activar el escudo

sudo ufw enable

  

Ver estado

sudo ufw status verbose

  

creamos un nano llamado firewall_status en var/www/html

  

Donde tendremos que crear un script donde se pueda ver el estado del firewall 

ACTIVIDAD 4

**

Nos movemos a cd var/www/html y crearemos un nano para html y para php
para eso haremos los siguientes comandos 

sudo nano telemetria.html
sudo nano telemetria.php

PARA ACCEDER A LO QUE HEMOS REALIZADOS NOS METEMOS A UN NAVEGADOR
http://192.168.1.52/index.html

Esto seria un ejemplo de la estructura FINAL que debemos tener
/var/www/html/
├── index.html          (Interfaz LCARS)
└── telemetria.php     (API que genera JSON)


						ACTVIDAD 2 MD4353.mis


Instalaremos un Docker con el siguiente comando:
sudo apt install docker.io

Luego levantaremos contenedores Apache, MariaDB, Alpine

Comando para levantar el contenedor APACHE:
sudo docker run -d --name apache-starfleet -p 8080:80 httpd

Comando para levantar el contenedor MariaDB:
sudo docker run -d --name mariadb-starfleet   -e MYSQL_ROOT_PASSWORD=enterprise   -e MYSQL_DATABASE=starfleet   mariadb

Comando para levantar el contenedor Alphine:
sudo docker run -it --name alpine-starfleet alpine sh

Luego crearemos una red para qu se comuniquen
sudo docker network create wp-net

con este comando contruimos el docker:

sudo docker build -f dokerfile.wp -t mi-wordpress:1.0 .
 
sudo docker run -d --name wp --network wp-net \
  -e WORDPRESS_DB_HOST=wp-db:3306 \
  -e WORDPRESS_DB_USER=wpuser \
  -e WORDPRESS_DB_PASSWORD=wppass \
  -e WORDPRESS_DB_NAME=wordpress \
  -p 8082:80 \
  -v wp-html:/var/www/html \
  mi-wordpress:1.0

Luego crear una carpeta llamada startfleet donde crearemos un index.html y un Dockerfile